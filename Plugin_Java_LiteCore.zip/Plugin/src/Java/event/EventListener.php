<?php

namespace Java\event;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\block\Block;
use pocketmine\level\Level;
use Java\Main;

/**
 * Class EventListener
 *
 * Event Listener for handling player interactions.
 *
 * @package Java\event
 */
class EventListener implements Listener
{
    /** @var Main */
    private $plugin;

    /** @var array */
    private $items;

    /**
     * EventListener constructor.
     *
     * @param Main $plugin
     * @param array $items
     */
    public function __construct(Main $plugin, array $items)
    {
        $this->plugin = $plugin;
        $this->items = $items;
    }

    /**
     * Handles player interact events.
     *
     * @param PlayerInteractEvent $event
     */
    public function interact(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();
        $custom = $item->getCustomName();
        $block = $event->getBlock();

        if ($custom === '§r§bВосстановление') {
            $this->replace($block->getLevel(), $block);
            $player->sendMessage("§r§aВы восстановили блоки!");
        }

        if ($custom === '§r§bУзнать ID') {
            $player->sendMessage("§r§cID блока: " . $block->getId());
        }
    }

    /**
     * Replaces blocks around a given block.
     *
     * @param Level $level
     * @param Block $block
     */
    private function replace(Level $level, Block $block)
    {
        $radius = 5;

        foreach ($this->items as $id => $ids) {
            for ($x = -$radius; $x <= $radius; $x++) {
                for ($y = -$radius; $y <= $radius; $y++) {
                    for ($z = -$radius; $z <= $radius; $z++) {
                        $target = $level->getBlock($block->add($x, $y, $z));
                        if ($target->getId() === $id) {
                            $level->setBlock($target, Block::get($ids));
                        }
                    }
                }
            }
        }
    }
}
?>
