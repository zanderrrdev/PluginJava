<?php

namespace Java\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\nbt\tag\CompoundTag;

/**
 * Class ChangeCommand
 *
 * Handles the 'change' command to give players special enchanted items.
 *
 * @package Java\command
 */
class ChangeCommand extends Command
{
    /**
     * ChangeCommand constructor.
     */
    public function __construct()
    {
        parent::__construct('change');
        $this->setDescription('Команда change');
    }

    /**
     * @param CommandSender $sender
     * @param string $label
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, string $label, array $args): bool
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Эту команду можно использовать только в игре.");
            return false;
        }

        if (count($args) < 1) {
            $sender->sendMessage("Использование: /change <restore|id>");
            return false;
        }

        switch ($args[0]) {
            case "restore":
                $this->give($sender, 352, "restore", "§r§bВосстановление", "§aВы получили зачарованную кость: Восстановление");
                break;

            case "id":
                $this->give($sender, 280, "id", "§r§bУзнать ID", "§aВы получили зачарованную кость: Узнать ID");
                break;

            default:
                $sender->sendMessage("Использование: /change <restore|id>");
                break;
        }

        return true;
    }

    /**
     * Gives the player an enchanted bone with specific properties.
     *
     * @param Player $player
     * @param string $nbt
     * @param string $custom
     * @param string $message
     */
    private function give(Player $player, int $id, string $nbt, string $custom, string $message): void
    {
        $item = Item::get($id, 0, 1);
        $item->setCustomName($custom);

        $enchantment = Enchantment::getEnchantment(7);
        $item->addEnchantment(new EnchantmentInstance($enchantment, 1));

        $nbt = $item->getNamedTag() ?? new CompoundTag("", []);
        $item->setNamedTag($nbt);

        $player->getInventory()->addItem($item);
        $player->sendMessage($message);
    }
}
?>
