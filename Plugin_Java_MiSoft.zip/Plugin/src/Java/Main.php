<?php

namespace Java;

use pocketmine\plugin\PluginBase;
use Java\command\ChangeCommand;
use Java\event\EventListener;

/**
 * Main class for the ChangeCommand plugin.
 *
 * This class handles the main lifecycle events of the plugin,
 * such as enabling and disabling, and logs relevant messages.
 *
 * @author Zanderrr
 * @link https://github.com/zanderrrdev/PluginJava
 */
class Main extends PluginBase
{
    /** @var array */
    private $items = [
        188 => 85,
        166 => 101,
        126 => 158,
        125 => 5,
        160 => 85
    ];

    /**
     * Called when the plugin is enabled.
     * Registers commands and event listeners.
     *
     * @return void
     */
    public function onEnable(): void
    {
        $this->getServer()->getCommandMap()->register('change', new ChangeCommand());
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this, $this->items), $this);
    }

    /**
     * Get the items array.
     *
     * @return array
     */
    public function getItems(): array
    {
        return $this->items;
    }
}
